// data/store.js
// Apenas para armazenar tokens em memória (simples, didático)
const tokens = {}; // tokens[tokenString] = { username, createdAt }

module.exports = { tokens };
